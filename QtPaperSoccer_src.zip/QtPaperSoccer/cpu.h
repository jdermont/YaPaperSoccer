#ifndef CPU_H
#define CPU_H

#include <random>
#include <vector>
#include <string>
#include <stack>
#include <deque>
#include <utility>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <functional>
#include <memory>
#include <chrono>
#include <stdint.h>
#include <mutex>
#include <thread>
#include <functional>
#include <map>
#include <fstream>
#include <tuple>
#include <atomic>

#include <sstream>
#include "field.h"

#define MAX_GOAL 900
#define MAX_ONE_EMPTY 850
#define MAX_CUTOFF 800
#define MIN_CUTOFF -700
#define MIN_GOAL_ONE_EMPTY -750
#define MIN_GOAL_NEXT_MOVE -800
#define MIN_GOAL -850
#define MIN_BLOCKED -900
#define NOTDEFINED 30101

#define MAXTIME 10000000L
#define VIRTUAL_LOSS 2
#define INF 100000000

using namespace std;
using namespace std::chrono;

enum class Difficulty {
    VERYEASY,EASY,NORMAL,ADVANCED,HARD
};

class SpinLock {
    std::atomic_flag locked = ATOMIC_FLAG_INIT ;
public:
    void lock() {
        while (locked.test_and_set(std::memory_order_acquire)) { ; }
    }
    void unlock() {
        locked.clear(std::memory_order_release);
    }
};

class Move {
public:
    short score;
    string move;
    bool terminate;
    int score2;
    int games;
    Player player;
    Move *parent;
    unsigned long hash;
    vector<Move*> moves;
    shared_ptr<SpinLock> lock;
    unsigned char virtualLoss;
    bool checked = false;
    explicit Move(short score = 0, string move = "", bool terminate = false, double score2 = 0, int games = 0, Player player = Player::NONE, Move *parent = NULL, unsigned long hash = 0L) : score(score), move(move), terminate(terminate), score2(score2), games(games), player(player), parent(parent), hash(hash) {
        virtualLoss = 0;
        lock.reset(new SpinLock());
    }
    virtual ~Move() { for (auto & m : moves) { delete m; } }
    friend ostream& operator<< (ostream &out, Move &move) {
        out << move.score << ": " << move.move;
        return out;
    }
    bool operator < (const Move& move) const {
        return move.score < score;
    }
    bool operator > (const Move& move) const {
        return move.score > score;
    }
};

class ShortMove {
public:
    short score;
    string move;

    explicit ShortMove(short score = 0, string move = "") : score(score), move(move) {

    }

};

class Cpu
{
public:
    vector<string> lines;
    Player player;
    int movesNum;
    shared_ptr<Field> field;
    Cpu(Player player, Difficulty difficulty, int numThreads, int time);
    void setField(Field *field);
    void setField(shared_ptr<Field> field);
    string getBestMove();
    string getBestMoveMCTS();
    void release();
    void printMoves(vector<Move*> &moves, int level);

    int ruchy;
    long maxTime;
    int g = 0;
    int time;

    stringstream ss;

private:
    Difficulty difficulty;
    int numThreads;
    int levels;
    unsigned int limit;
    vector<vector<int> > scoresArray;
    bool measureTime;
    high_resolution_clock::time_point start;
    bool alreadyBlocking;
    bool alreadyBlocked;
    bool isReleased;
    uint64_t seed[2];
    void FisherYates(vector<int> & ints);
    mt19937 mt;

    const double C = 0.5;
    bool provenEnd = false;

    uint64_t xorshift128plus();
    unsigned int randomInt(unsigned int max);
    void updateScores();
    static int hashPaths(vector<Path> &paths);
    static int hashPaths(vector<Path*> &paths);
    Move*chooseBestMove(vector<Move*> & moves);
    vector<Move*> getMovesEasy();
    vector<Move*> getMovesSophisticated(int level);
    int getScore(Player player, int level, int alpha, int beta);
    vector<Path> makeMove(string &move);
    void undoMove(vector<Path> & paths);
    int nextNode(char & c);

    int simulateOnePointers2(Player currentPlayer, int limes);
    int simulateOnePointers3(Player currentPlayer, int limes, map<unsigned long,pair<int,int>> & tt, mutex & ttLock, int poziomy);
    vector<Move*> getMoves2(Move *parent, Player player, int limit, int level = 0, int poziomy = 0);
    vector<ShortMove*> getMovePointers2(Player player, int limit, int level = 0);
    int getMovesScore2(Player player, int limit, int level = 0);
    void wybierz4(vector<Move*> & moves, int games, int level);
    void wybierz4(vector<Move*> & moves, int games, int level, map<unsigned long,pair<int,int>> & tt, mutex & ttLock);
    void fillRuchy2(vector<Move*> & moves, mutex & lock);

    map<unsigned long,pair<int,int>> ttGlobal;
    mutex ttLockGlobal;
    Move *lastMove;
};

#endif // CPU_H
