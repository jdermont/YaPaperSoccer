#ifndef GAME_H
#define GAME_H

#include <string>
#include "field.h"

class Game
{
public:
    Player startingPlayer;
    Player currentPlayer;
    Field *field;
    string notation;
    string notation2;
    int ruchy;
    bool started;

    Game();
    ~Game() { delete field; }
    void startGame();
    bool isOver();
    void doStartMove(string notation);

    void doMove(string move);
    void doMove2(string &move);
    void doMove2(char c);
    int nextNode(char c);
    void changePlayer();
    Player getWinner();

    vector<Path> paths;
    void undo();
    bool almost = false;
    void confirm();
private:

};

#endif // GAME_H
