#ifndef WORKERTHREAD_H
#define WORKERTHREAD_H

#include <QThread>
#include <memory>
#include <QSettings>
#include "field.h"
#include "cpu.h"

using namespace std;

class WorkerThread : public QThread
{
    Q_OBJECT
public:
    WorkerThread(Field *field, Player player, int ruchy) : player(player), ruchy(ruchy) {
        this->field.reset(new Field(Size::NORMAL,false));
        this->field->ball = field->ball;
        this->field->matrix = field->matrix;
        this->field->matrixNodes = field->matrixNodes;
        this->field->matrixNeibghours = field->matrixNeibghours;
    }
    virtual void run();

private:
    shared_ptr<Field> field;
    Player player;
    int ruchy;

signals:
    void moveCalculated(char c);
    void moveLogs(string logs);
};

#endif // WORKERTHREAD_H
