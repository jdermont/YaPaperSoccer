#include "game.h"

Game::Game() : startingPlayer(Player::ONE), currentPlayer(Player::NONE) {
    field = new Field(Size::NORMAL, false);
    started = false;
}

void Game::startGame() {
    delete field;
    field = new Field(Size::NORMAL,false);
    startingPlayer = startingPlayer==Player::ONE?Player::TWO:Player::ONE;
    currentPlayer = startingPlayer;
    ruchy = 0;
    started = true;
    notation = currentPlayer==Player::ONE?"B":"A";
    notation2 = currentPlayer==Player::ONE?"B":"A";
}

bool Game::isOver() {
    return field->isBlocked(field->ball) || field->goal(field->ball)!=Player::NONE;
}

#include <iostream>
using namespace std;
void Game::doStartMove(string notation) {
    for (auto & c :notation) {
        if (c == 'A') {
            startingPlayer = Player::TWO;
            currentPlayer = Player::TWO;
           this->notation = "A";
        } else if (c == 'B') {
            startingPlayer = Player::ONE;
            currentPlayer = Player::ONE;
            this->notation = "B";
        } else if (c >= '0' && c <= '9') {
            doMove2(c);
        }
    }
}

#include <iostream>
using namespace std;
void Game::doMove(string move) {
    for (auto &c : move) {
        notation += c;
        notation2 += field->nowaNotacja[field->ball] + c;
        int n = nextNode(c);
        paths.push_back(Path(field->ball,n));
        field->addEdge(field->ball,n,currentPlayer);
        field->ball = n;
        if (!isOver() && !field->passNextDone(field->ball)) {
            //changePlayer();
            almost = true;
        } else if (isOver()) {
            almost = true;
        }
    }
    ruchy++;
    cout << notation2 << endl;
}

void Game::confirm() {
    almost = false;
    paths.clear();
    if (!isOver()) changePlayer();
    notation += ',';
}

void Game::undo() {
    if (paths.size() > 0) {
        Path path = paths[paths.size()-1];
        paths.pop_back();
        field->removeEdge(path.a,path.b);
        field->ball = path.a;
        almost = false;
        notation.pop_back();
        notation2.resize(notation2.size()-3);
    }
}

void Game::doMove2(string &move) {
    for (int i=0;i<move.size();i++) {
        int n = nextNode(move[i]);
        field->addEdge(field->ball,n,currentPlayer);
        field->ball = n;
        if (!isOver() && !field->passNextDone(field->ball)) {
            changePlayer();
            move.erase(0,i+1);
            break;
        }
    }
    cout << notation2 << endl;
}

void Game::doMove2(char c) {
    notation += c;
    notation2 += field->nowaNotacja[field->ball] + c;
    int n = nextNode(c);
    field->addEdge(field->ball,n,currentPlayer);
    field->ball = n;
    if (!isOver() && !field->passNextDone(field->ball)) {
        changePlayer();
        ruchy++;
        notation += ",";
    }
}

int Game::nextNode(char c) {
    switch(c) {
        case '5': return field->getNeibghour(-1,1);
        case '4': return field->getNeibghour(0,1);
        case '3': return field->getNeibghour(1,1);
        case '6': return field->getNeibghour(-1,0);
        case '2': return field->getNeibghour(1,0);
        case '7': return field->getNeibghour(-1,-1);
        case '0': return field->getNeibghour(0,-1);
        case '1': return field->getNeibghour(1,-1);
    }
    return -1;
}

void Game::changePlayer() {
    currentPlayer = currentPlayer==Player::ONE?Player::TWO:Player::ONE;
}

Player Game::getWinner() {
    if (field->goal(field->ball)!=Player::NONE) {
        if (field->goal(field->ball) == Player::ONE) return Player::TWO;
        return Player::ONE;
    }
    if (currentPlayer == Player::ONE) return Player::TWO;
    return Player::ONE;
}
