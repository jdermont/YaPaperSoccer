#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLayout>
#include <memory>
#include "boisko.h"
#include "game.h"
#include "cpu.h"
#include "secondwindow.h"
#include "workerthread.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void keyPressEvent(QKeyEvent *);
    void onBoiskoClick(QPoint &);

private:
    Ui::MainWindow *ui;
    SecondWindow secondWindow;
    shared_ptr<Game> game;
    Boisko *boisko;
    string move;
    string reverse(string input);

    void calcMove(bool forHuman);
    bool calculating = false;

public slots:
    void onMoveCalculated(char c);
    void onMoveCalculated2(char c);
    void onStartClicked(string notation);

signals:
    void sendMessage(string message);
    void sendNotation(string notation);
    void sendNotation2(string notation);
    void sendGameState(bool inGame);
    void sendWinner(int winner);
};

#endif // MAINWINDOW_H
