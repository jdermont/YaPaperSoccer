#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    qRegisterMetaType<string>("string");
    ui->setupUi(this);
    game = std::make_shared<Game>();
    boisko = new Boisko(this);
    boisko->setGame(game);
    MainWindow::setCentralWidget(boisko);

    connect(this, SIGNAL(sendMessage(string)), &secondWindow, SLOT(onMessage(string)));
    connect(this, SIGNAL(sendNotation(string)), &secondWindow, SLOT(onNotation(string)));
    connect(this, SIGNAL(sendNotation2(string)), &secondWindow, SLOT(onNotation2(string)));
    connect(this, SIGNAL(sendGameState(bool)), &secondWindow, SLOT(onGameStateChanged(bool)));
    connect(this, SIGNAL(sendWinner(int)), &secondWindow, SLOT(onWinner(int)));
    connect(&secondWindow, SIGNAL(startClicked(string)), this, SLOT(onStartClicked(string)));
    secondWindow.show();
}

string MainWindow::reverse(string input) {
    string output = "";
    for (auto &i : input) {
        switch (i) {
            case '0': output += '4'; break;
            case '1': output += '5'; break;
            case '2': output += '6'; break;
            case '3': output += '7'; break;
            case '4': output += '0'; break;
            case '5': output += '1'; break;
            case '6': output += '2'; break;
            case '7': output += '3'; break;
        }
    }
    return output;
}

MainWindow::~MainWindow()
{
    delete boisko;
    delete ui;
}

void MainWindow::keyPressEvent(QKeyEvent *event) {
    QWidget::keyPressEvent(event);
    if (!calculating) {
        if (event->key() == Qt::Key_Backspace) {
            game->undo();
            emit(sendNotation(game->notation));
            emit(sendNotation2(game->notation2));
        } else if (event->key() == Qt::Key_Shift) {
            if (!game->started || game->isOver() || game->almost) {

            } else {
                calcMove(true);
            }
        }
    }

    boisko->repaint();
}

void MainWindow::onBoiskoClick(QPoint &p) {
    if (calculating) return;
    if (!game->almost) if (!game->started || game->isOver()) return;

    Point bP = game->field->getPosition(game->field->ball);

    if (game->almost) {
        if (p.x() == bP.x && p.y() == bP.y) {
            game->confirm();
            if (game->isOver()) {
                sendGameState(!game->isOver());
                emit sendWinner(game->getWinner() == Player::ONE ? 0 : 1);
            } else
            if (game->currentPlayer == Player::ONE) {
                QSettings settings("qtpapersoccer", QSettings::IniFormat);
                if (settings.value("computer",true).toBool()) {
                    calcMove(false);
                }
            }
        }
    } else if (abs(p.x()-bP.x) <= 1 && abs(p.y()-bP.y) <= 1 && game->field->getNeibghour(p.x()-bP.x,p.y()-bP.y) != -1) {

        if (p.x() - bP.x == -1) {
            if (p.y() - bP.y == -1) game->doMove("7");
            else if (p.y() - bP.y == 0) game->doMove("6");
            else game->doMove("5");
        } else if (p.x() - bP.x == 0) {
            if (p.y() - bP.y == -1) game->doMove("0");
            else game->doMove("4");
        } else {
            if (p.y() - bP.y == -1) game->doMove("1");
            else if (p.y() - bP.y == 0) game->doMove("2");
            else game->doMove("3");
        }
        boisko->repaint();
    }

    emit(sendNotation(game->notation));
    emit(sendNotation2(game->notation2));

}

void MainWindow::onMoveCalculated(char c) {
    game->doMove2(c);
    emit sendNotation(game->notation);
    emit(sendNotation2(game->notation2));
    boisko->repaint();
    calculating = false;
    emit sendGameState(!game->isOver());
    if (game->isOver()) {
        emit sendWinner(game->getWinner() == Player::ONE ? 0 : 1);
    }
}

void MainWindow::onMoveCalculated2(char c) {
    game->doMove(string(1,c));
    emit sendNotation(game->notation);
    emit(sendNotation2(game->notation2));
    boisko->repaint();
    if (game->almost) calculating = false;
}

void MainWindow::calcMove(bool forHuman) {
    calculating = true;
    if (forHuman) {
        emit sendMessage("Calculating move for human...");
    } else {
        emit sendMessage("Calculating move...");
    }
    // Create an instance of your woker
    WorkerThread *workerThread = new WorkerThread(game->field,game->currentPlayer,game->ruchy);
    // Connect our signal and slot
    if (forHuman) {
        connect(workerThread, SIGNAL(moveCalculated(char)),
                              SLOT(onMoveCalculated2(char)));
    } else {
        connect(workerThread, SIGNAL(moveCalculated(char)),
                              SLOT(onMoveCalculated(char)));
    }
    connect(workerThread, SIGNAL(moveLogs(string)), &secondWindow, SLOT(onMoveLogs(string)));
    connect(workerThread, SIGNAL(finished()), workerThread,
                          SLOT(deleteLater()));
    workerThread->start();
}

void MainWindow::onStartClicked(string notation) {
    game->startGame();
    if (notation.size() > 0) {
        game->doStartMove(notation);
    }
    emit sendMessage("Game started");
    emit sendNotation(game->notation);
    emit(sendNotation2(game->notation2));
    if (game->currentPlayer == Player::ONE) {
        QSettings settings("qtpapersoccer", QSettings::IniFormat);
        if (settings.value("computer",true).toBool()) {
            calcMove(false);
        }
    }
    repaint();
    emit sendGameState(true);
}
