#include "boisko.h"

Boisko::Boisko(QWidget *parent) : QWidget(parent)
{
    setMouseTracking(true);
}

#include <iostream>

using namespace std;

void Boisko::paintEvent(QPaintEvent *event) {
    QWidget::paintEvent(event);

    // calculating size
    QRect rect = event->rect();
    int width = rect.width();
    int height = rect.height();
    blocksize = (double)height / (game->field->height+3);
    marginWidth = (width - blocksize * game->field->width) / 2.0f;
    if (marginWidth <= 0) {
        blocksize = (double)width / (game->field->width);
        marginWidth = (width - blocksize * game->field->width) / 2.0f;
    }
    marginHeight = (1.5f * blocksize);

    // paint stuff
    QPen white(QColor("#FFFFFF"), LINE_WIDTH, Qt::SolidLine, Qt::RoundCap);
    QPen red(QColor("#FF0000"), LINE_WIDTH, Qt::SolidLine, Qt::RoundCap);
    QPen gray(QColor("#909090"), LINE_WIDTH, Qt::SolidLine, Qt::RoundCap);
    QPen black(QColor("#000000"), LINE_WIDTH, Qt::SolidLine, Qt::RoundCap);
    QPen blue(QColor("#0000FF"), LINE_WIDTH, Qt::SolidLine, Qt::RoundCap);
    QPen fieldLine(QColor("#CCCCEE"), LINE_WIDTH, Qt::SolidLine, Qt::RoundCap);
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    QFont font;
    int i;

    font.setPixelSize(blocksize/3);
    painter.setFont(font);

    // background
    painter.fillRect(rect,QColor("#FFFFFF"));

    // background lines
    painter.setPen(fieldLine);
    i = 0;
    while (marginWidth + i * blocksize >= 0) {
        painter.drawLine(marginWidth+blocksize*i,0,marginWidth+blocksize*i,height);
        i--;
    }
    i = 1;
    while (marginWidth + i * blocksize <= width) {
        painter.drawLine(marginWidth+blocksize*i,0,marginWidth+blocksize*i,height);
        i++;
    }
    i = 0;
    while (marginHeight + i * blocksize >= 0) {
        painter.drawLine(0,marginHeight+blocksize*i,width,marginHeight+blocksize*i);
        i--;
    }
    i = 1;
    while (marginHeight + i * blocksize <= height) {
        painter.drawLine(0,marginHeight+blocksize*i,width,marginHeight+blocksize*i);
        i++;
    }

    for (auto& edge : game->field->getEdges()) {
        if (edge.player == Player::NONE) {
            painter.setPen(black);
        } else if (edge.player == Player::TWO) {
            painter.setPen(red);
        } else {
            painter.setPen(blue);
        }
        if (flip) {
            edge.a.x = game->field->width - edge.a.x;
            edge.b.x = game->field->width - edge.b.x;
            painter.drawLine(marginWidth+blocksize*edge.a.x,marginHeight+blocksize*edge.a.y,marginWidth+blocksize*edge.b.x,marginHeight+blocksize*edge.b.y);
        } else {
            painter.drawLine(marginWidth+blocksize*edge.a.x,marginHeight+blocksize*edge.a.y,marginWidth+blocksize*edge.b.x,marginHeight+blocksize*edge.b.y);
        }
    }

//    red.setWidth(BOLD_LINE_WIDTH);
//    blue.setWidth(BOLD_LINE_WIDTH);

//    if (game->currentPlayer == Player::ONE) {
//        painter.setPen(red);
//    } else {
//        painter.setPen(blue);
//    }

//    for (auto& path : game->paths) {
//        Point a = game->field->getPosition(path.a);
//        Point b = game->field->getPosition(path.b);
//        Edge edge = Edge(a,b);
//        painter.drawLine(marginWidth+blocksize*edge.a.x,marginHeight+blocksize*edge.a.y,marginWidth+blocksize*edge.b.x,marginHeight+blocksize*edge.b.y);
//    }

    if (game->almost) {
        red.setWidth(BIG_BALL_SIZE);
        blue.setWidth(BIG_BALL_SIZE);
        black.setWidth(BIG_BALL_SIZE);
    } else {
        red.setWidth(BALL_SIZE);
        blue.setWidth(BALL_SIZE);
        black.setWidth(BALL_SIZE);
    }

    string notacja[105] = {};

    notacja[11] = "AK";
    notacja[22] = "AL";
    notacja[33] = "AM";
    notacja[44] = "BK";
    notacja[55] = "CK";
    notacja[66] = "CL";
    notacja[77] = "CM";

    notacja[1] = "AN";
    notacja[12] = "AO";
    notacja[23] = "AP";
    notacja[34] = "AQ";
    notacja[45] = "BL";
    notacja[56] = "CN";
    notacja[67] = "CO";
    notacja[78] = "CP";
    notacja[89] = "CQ";

    notacja[2] = "AR";
    notacja[13] = "AS";
    notacja[24] = "DK";
    notacja[35] = "DL";
    notacja[46] = "DM";
    notacja[57] = "DN";
    notacja[68] = "DO";
    notacja[79] = "CR";
    notacja[90] = "CS";

    notacja[3] = "AT";
    notacja[14] = "AU";
    notacja[25] = "DP";
    notacja[36] = "DQ";
    notacja[47] = "DR";
    notacja[58] = "DS";
    notacja[69] = "DT";
    notacja[80] = "CT";
    notacja[91] = "CU";

    notacja[4] = "AV";
    notacja[15] = "AW";
    notacja[26] = "DU";
    notacja[37] = "DV";
    notacja[48] = "DW";
    notacja[59] = "DX";
    notacja[70] = "DY";
    notacja[81] = "CV";
    notacja[92] = "CW";

    notacja[5] = "EK";
    notacja[16] = "EL";
    notacja[27] = "EM";
    notacja[38] = "EN";
    notacja[49] = "XK";
    notacja[60] = "FK";
    notacja[71] = "FL";
    notacja[82] = "FM";
    notacja[93] = "FN";

    notacja[6] = "HK";
    notacja[17] = "HL";
    notacja[28] = "GK";
    notacja[39] = "GL";
    notacja[50] = "GM";
    notacja[61] = "GN";
    notacja[72] = "GO";
    notacja[83] = "JK";
    notacja[94] = "JL";

    notacja[7] = "HM";
    notacja[18] = "HN";
    notacja[29] = "GP";
    notacja[40] = "GQ";
    notacja[51] = "GR";
    notacja[62] = "GS";
    notacja[73] = "GT";
    notacja[84] = "JM";
    notacja[95] = "JN";

    notacja[8] = "HO";
    notacja[19] = "HP";
    notacja[30] = "GU";
    notacja[41] = "GV";
    notacja[52] = "GW";
    notacja[63] = "GX";
    notacja[74] = "GY";
    notacja[85] = "JO";
    notacja[96] = "JP";

    notacja[9] = "HQ";
    notacja[20] = "HR";
    notacja[31] = "HS";
    notacja[42] = "HT";
    notacja[53] = "IK";
    notacja[64] = "JQ";
    notacja[75] = "JR";
    notacja[86] = "JS";
    notacja[97] = "JT";

    notacja[21] = "HU";
    notacja[32] = "HV";
    notacja[43] = "HW";
    notacja[54] = "IL";
    notacja[65] = "JU";
    notacja[76] = "JV";
    notacja[87] = "JW";

    painter.setPen(gray);
    for (int i=0;i<game->field->size;i++) {
        Point p = game->field->getPosition(i);
//        painter.drawText(marginWidth+2+blocksize*p.x,-2+marginHeight+blocksize*p.y,QString::number(i));
        painter.drawText(marginWidth+2+blocksize*p.x,-2+marginHeight+blocksize*p.y,QString::fromStdString(notacja[i]));
    }

    painter.setPen(game->currentPlayer==Player::TWO?red:blue);
    Point ball = game->field->getPosition(game->field->ball);
    if (game->started) painter.drawPoint(marginWidth+blocksize*ball.x,marginHeight+blocksize*ball.y);

//    for (int i=0;i<game->field->cutOffGoalArray.size();i++) {
//        if (game->field->cutOffGoalArray[i] == Player::ONE) {
//            painter.setPen(red);
//            Point ball = game->field->getPosition(i);
//            painter.drawPoint(marginWidth+blocksize*ball.x,marginHeight+blocksize*ball.y);
//        } else if (game->field->cutOffGoalArray[i] == Player::TWO) {
//            painter.setPen(blue);
//            Point ball = game->field->getPosition(i);
//            painter.drawPoint(marginWidth+blocksize*ball.x,marginHeight+blocksize*ball.y);
//        }
//    }

    red.setWidth(BALL_SIZE);
    blue.setWidth(BALL_SIZE);
    black.setWidth(BALL_SIZE);

    if (hoverX >= 0 && hoverY >= -1)
    {
        painter.setPen(black);
        painter.drawPoint(marginWidth+blocksize*hoverX,marginHeight+blocksize*hoverY);
    }
}

#include <iostream>
#include "mainwindow.h"
using namespace std;

void Boisko::mouseReleaseEvent(QMouseEvent *event) {
    double x = (event->x() - marginWidth) / blocksize;
    double y = (event->y() - marginHeight) / blocksize;
    int X = round(x);
    int Y = round(y);
    MainWindow *m = static_cast<MainWindow *>(this->parent());
    QPoint pt(X,Y);
    m->onBoiskoClick(pt);

}

void Boisko::mouseMoveEvent(QMouseEvent *event) {
    double x = (event->x() - marginWidth) / blocksize;
    double y = (event->y() - marginHeight) / blocksize;
    hoverX = round(x);
    hoverY = round(y);
    repaint();
}

void Boisko::setGame(shared_ptr<Game> game) {
    this->game = game;
}
