#include "cpu.h"

Cpu::Cpu(Player player, Difficulty difficulty, int numThreads, int time) : isReleased(false), player(player), difficulty(difficulty), numThreads(numThreads), mt(random_device()()), time(time) {
    std::random_device rd;

    seed[0] = rd();
    seed[0] = (seed[0]<<32) + rd();
    seed[1] = rd();
    seed[1] = (seed[1]<<32) + rd();

//    seed[0] = 123456789L;
//    seed[1] = 6549878L;

    switch (difficulty) {
    case Difficulty::VERYEASY: limit = 20; break;
    case Difficulty::EASY: limit = 30; break;
    case Difficulty::NORMAL: limit = 5000000; levels = -2; break;
    case Difficulty::ADVANCED: limit = 500; levels = 2; break;
    case Difficulty::HARD: limit = 250; levels = 8; break;
    }
    measureTime = difficulty==Difficulty::HARD?true:false;
    ruchy = 0;
    maxTime = MAXTIME;

}

void Cpu::setField(Field *field) {
    this->field.reset(field);
    updateScores();
}

void Cpu::setField(shared_ptr<Field> field) {
    this->field = field;
    updateScores();
}

void Cpu::updateScores() {
    scoresArray.resize(field->size,vector<int>(2));

    // HARD BACKER
    for (int i=0;i<field->size;i++) {
        int r = randomInt(3) - 1;
        Point p = field->getPosition(i);
        int x = p.x;
        int y = p.y;

        int score = 2*abs(y-field->height) + r;
        int score2 = 2*abs(y) + r;

        scoresArray[i][0] = score;
        scoresArray[i][1] = score2;
    }

}

uint64_t Cpu::xorshift128plus() {
    uint64_t x = seed[0];
    uint64_t const y = seed[1];
    seed[0] = y;
    x ^= x << 23; // a
    seed[1] = x ^ y ^ (x >> 17) ^ (y >> 26); // b, c
    return seed[1] + y;
}

unsigned int Cpu::randomInt(unsigned int max) {
    return xorshift128plus()%max;
}

void Cpu::FisherYates(vector<int> & ints) { //implementation of Fisher
    int i, j, tmp; // create local variables to hold values for shuffle

    for (i = ints.size() - 1; i > 0; i--) { // for loop to shuffle
        j = randomInt(i+1);; //randomise j for shuffle with Fisher Yates
        tmp = ints[j];
        ints[j] = ints[i];
        ints[i] = tmp;
    }
}

string Cpu::getBestMove() {
    movesNum = 0;
    if (field->isNextMoveGameover(player==Player::ONE?Player::TWO:Player::ONE)) {
        switch (difficulty) {
        case Difficulty::VERYEASY:
            if (randomInt(100) < 20) return field->shortWinningMoveForPlayer(player);
            break;
        case Difficulty::EASY:
            if (randomInt(100) < 60) return field->shortWinningMoveForPlayer(player);
            break;
        default:
            return field->shortWinningMoveForPlayer(player);
        }
    }

    vector<Move*> moves;
    switch (difficulty) {
    case Difficulty::VERYEASY:
    case Difficulty::EASY:
        moves = getMovesEasy();
        break;
    case Difficulty::HARD: {
        //        if (ruchy <= 4) maxTime = 500000L;
        //        else if (ruchy <= 8) maxTime = 750000L;
        //        else if (ruchy <= 12) maxTime = 1250000L;
        //        else maxTime = 1250000L + (ruchy-12) * 1000000L;
        //        maxTime = min(MAXTIME,maxTime);
        start = high_resolution_clock::now();
        alreadyBlocking = field->isCutOffFromOpponentGoal(player==Player::ONE?Player::TWO:Player::ONE);
        alreadyBlocked = field->isCutOffFromOpponentGoal(player);
        moves = getMovesSophisticated(0);
        cout << "size " << moves.size() << endl;
        Move* bestMoveSoFar = chooseBestMove(moves);
        for (int i=1;i<levels;i++) {
            int alpha = MIN_BLOCKED-(levels-1);
            shuffle(moves.begin(),moves.end(),mt);
            for (auto &move : moves) {
                if (move->terminate) {
                    if (move->score > alpha) alpha = move->score;
                    continue;
                }
                vector<Path> paths = makeMove(move->move);
                move->score = getScore(player==Player::ONE?Player::TWO:Player::ONE,i-1,alpha,MAX_GOAL+(levels-1));
                undoMove(paths);
                movesNum++;
                if (move->score == NOTDEFINED) {
                    string output = bestMoveSoFar->move;
                    for (auto & m : moves) { delete m; }
                    return output;
                }
                if (move->score > 200 || move->score < -200) {
                    move->terminate = true;
                }
                if (move->score > alpha) alpha = move->score;
            }
            bestMoveSoFar = chooseBestMove(moves);
        }
        string output = bestMoveSoFar->move;
        for (auto & m : moves) { delete m; }
        return output;
    }
    default:
        alreadyBlocking = field->isCutOffFromOpponentGoal(player==Player::ONE?Player::TWO:Player::ONE);
        alreadyBlocked = field->isCutOffFromOpponentGoal(player);
        moves = getMovesSophisticated(levels-1);
    }

    Move* move = chooseBestMove(moves);
    string output = move->move;
    for (auto & m : moves) { delete m; }
    return output;
}

Move* Cpu::chooseBestMove(vector<Move*> &moves) {
    sort(moves.begin(),moves.end(), [](Move *a, Move *b) -> bool {
        return a->score > b->score;
    });

    int n = 0;
    int last = NOTDEFINED;
    for (auto &move : moves) {
        if (move->score < -100) break;
        if (last == NOTDEFINED) last = move->score;
        else if (last > move->score) break;
        n++;
    }
    if (n < 2) return moves[0];
    return moves[randomInt(n)];
}

vector<Move*> Cpu::getMovesEasy() {
    vector<Move*> moves; moves.reserve(limit);
    deque<pair<int,vector<Path> > > talia;
    vector<int> vertices; vertices.reserve(20);
    vector<int> pathCycles; pathCycles.reserve(20);
    vector<int> blockedMoves; blockedMoves.reserve(20);
    string str;
    vertices.push_back(field->ball);
    talia.push_front(make_pair(field->ball,vector<Path>()));
    vector<int> ns(8);
    while (!talia.empty() && moves.size() < limit) {
        pair<int,vector<Path> > v_paths;
        v_paths = talia.back();
        talia.pop_back();
        int t = v_paths.first;
        vector<Path> & paths = v_paths.second;
        for (auto &p : paths) {
            str += field->getDistanceChar(p.a,p.b);
            field->addEdge(p.a,p.b);
            vertices.push_back(p.b);
        }
        field->ball = t;
        field->fillFreeNeibghours(ns,t);
        FisherYates(ns);
        for (auto &n : ns) {
            Player goal = field->goal(n);
            if (field->passNext(n) && !field->isAlmostBlocked(n) && goal == Player::NONE) {
                vector<Path> newPaths(paths);
                newPaths.push_back(Path(t,n));
                if (find(vertices.begin(), vertices.end(), n) != vertices.end()) {
                    int newPathsHash = hashPaths(newPaths);
                    if (find(pathCycles.begin(), pathCycles.end(), newPathsHash) == pathCycles.end()) {
                        pathCycles.push_back(newPathsHash);
                        talia.push_front(make_pair(n,newPaths));
                    }
                } else talia.push_front(make_pair(n,newPaths));
            } else {
                field->addEdge(t,n);
                field->ball = n;
                int score = scoresArray[n][player==Player::ONE?0:1];
                if (goal != Player::NONE) {
                    if (goal == player) score = MIN_GOAL;
                    else score = MAX_GOAL;
                } else if (field->isBlocked(n)) {
                    vector<Path> newPaths(paths);
                    newPaths.push_back(Path(t,n));
                    int newPathsHash = hashPaths(newPaths);
                    if (find(blockedMoves.begin(), blockedMoves.end(), newPathsHash) != blockedMoves.end()) {
                        field->ball = t;
                        field->removeEdge(t,n);
                        continue;
                    }
                    blockedMoves.push_back(newPathsHash);
                    score = MIN_BLOCKED;
                } else {
                    int chance = difficulty==Difficulty::VERYEASY?60:90;
                    if (randomInt(100) < chance && field->isNextMoveGameover(player)) {
                        score = MIN_GOAL_NEXT_MOVE;
                    }
                }
                field->ball = t;
                field->removeEdge(t,n);
                str += field->getDistanceChar(t,n);
                movesNum++;
                moves.push_back(new Move(score,str));
                str.pop_back();
                if (moves.size() >= limit) break;
            }
        }
        vertices.erase(vertices.begin()+1,vertices.end());
        str.clear();
        for (auto &p : paths) field->removeEdge(p.a,p.b);
        field->ball = vertices[0];
    }
    return moves;
}

vector<Move*> Cpu::getMovesSophisticated(int level) {
    Player opponent = player==Player::ONE?Player::TWO:Player::ONE;
    int alpha = MIN_BLOCKED-level;
    int beta = MAX_GOAL+level;
    vector<Move*> moves; moves.reserve(50);
    deque<pair<int,vector<Path> > > talia;
    vector<int> vertices; vertices.reserve(25);
    vector<int> pathCycles; pathCycles.reserve(25);
    vector<int> blockedMoves; blockedMoves.reserve(25);
    string str = "";
    vertices.push_back(field->ball);
    talia.push_back(make_pair(field->ball,vector<Path>()));
    vector<int> ns(8);
    vector<int> konceEdges;
    bool check = true;
    if (!field->onlyOneEmpty()) {
        konceEdges = field->fillBlockedKonce();
        field->calculateDistances2(player);
        check = field->distances[field->ball] < 3;
    }

//    set<int> begin;
//    if (this->player == Player::ONE) {
//        begin = field->dfs(field->ball);
//        begin.insert(field->ball);
//    }
    int loop = 0;
    while (!talia.empty() && moves.size() < limit) {
        loop++;
        pair<int,vector<Path> > v_paths;
        if ((loop&15) == 0) {
            v_paths = talia.front();
            talia.pop_front();
        } else {
            v_paths = talia.back();
            talia.pop_back();
        }
        int t = v_paths.first;
        vector<Path> & paths = v_paths.second;
        for (auto &p : paths) {
            str += field->getDistanceChar(p.a,p.b);
            field->addEdge(p.a,p.b);
            vertices.push_back(p.b);
        }
        field->ball = t;
        field->fillFreeNeibghours(ns,t);
        FisherYates(ns);
        for (auto &n : ns) {
            if (!field->isAlmostBlocked(n) && field->passNext(n)) {
                vector<Path> newPaths(paths);
                newPaths.push_back(Path(t,n));
                if (find(vertices.begin(), vertices.end(), n) != vertices.end()) {
                    int newPathsHash = hashPaths(newPaths);
                    if (find(pathCycles.begin(), pathCycles.end(), newPathsHash) == pathCycles.end()) {
                        pathCycles.push_back(newPathsHash);
                        talia.push_back(make_pair(n,newPaths));
//                        if (this->player == Player::ONE || true) {
//                            field->addEdge(t,n);
//                            set<int> begin2 = field->dfs(n);
//                            begin2.insert(n);
//                            field->removeEdge(t,n);

//                            if (begin != begin2) {
//                                talia.push_back(make_pair(n,newPaths));
//                            }
//                        } else {
//                            talia.push_back(make_pair(n,newPaths));
//                        }
                    }
                } else talia.push_back(make_pair(n,newPaths));
            } else {
                Player goal = field->goal(n);
                bool terminate = false;
                field->addEdge(t,n);
                field->ball = n;
                int p = this->player==Player::ONE?0:1;
                int score = scoresArray[n][p];
                int distance = scoresArray[n][this->player==Player::ONE?0:1];
                if (goal != Player::NONE) {
                    terminate = true;
                    if (goal == this->player) score = MIN_GOAL-(levels-1);
                    else score = MAX_GOAL+(levels-1);
                } else {
                    if (field->isBlocked(n)) {
                        vector<Path> newPaths(paths);
                        newPaths.push_back(Path(t,n));
                        int newPathsHash = hashPaths(newPaths);
                        if (find(blockedMoves.begin(), blockedMoves.end(), newPathsHash) != blockedMoves.end()) {
                            field->ball = t;
                            field->removeEdge(t,n);
                            continue;
                        }
                        blockedMoves.push_back(newPathsHash);
                        score = MIN_BLOCKED-(levels-1);
                        terminate = true;
                    } else {
                        if (check && field->isNextMoveGameover(player)) {
                            terminate = true;
                            score = MIN_GOAL_NEXT_MOVE-(levels-1);
                        } else if (field->onlyOneEmpty()) {
                            terminate = true;
                            score = MAX_ONE_EMPTY+(levels-1);
                        } else if (field->onlyTwoEmpty()) {
                            terminate = true;
                            score = MIN_GOAL_ONE_EMPTY+(levels-1);
                        } else if (!alreadyBlocked && field->passNextDone2(t) && field->isCutOffFromOpponentGoal(this->player)) {
                            terminate = true;
                            score = MIN_CUTOFF-level;
                        } else if (!alreadyBlocking && field->passNextDone2(t) && field->isCutOffFromOpponentGoal(this->player==Player::ONE?Player::TWO:Player::ONE)) {
                            terminate = true;
                            score = MAX_CUTOFF+(levels-1);
                            alreadyBlocking = true;
                            int t = limit;
                            limit = 30;
                            int s = getScore(opponent,-1,-500,MAX_GOAL+level);
                            limit = t;
                            alreadyBlocking = false;
                            terminate = true;
                            if (s > -100) score = MAX_CUTOFF+(levels-1);
                            else score = s;
                        } else {
                            if (level > 0) {
                                score = getScore(opponent,level-1,alpha,beta);
                                if (score == NOTDEFINED) {
                                    field->removeEdge(t,n);
                                    for (auto &p : paths) field->removeEdge(p.a,p.b);
                                    for (int i=0;i<konceEdges.size()/2;i++) {
                                        field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                                    }
                                    field->ball = vertices[0];
                                    str += field->getDistanceChar(t,n);
                                    movesNum++;
                                    moves.push_back(new Move(score,str,terminate, 0, 0, this->player, NULL));
                                    return moves;
                                }
                            } else if (level == 0 && field->isNextMoveGameover(opponent)) {
                                score = getScore(opponent,level-1,alpha,beta);
                                if (score == NOTDEFINED) {
                                    field->removeEdge(t,n);
                                    for (auto &p : paths) field->removeEdge(p.a,p.b);
                                    for (int i=0;i<konceEdges.size()/2;i++) {
                                        field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                                    }
                                    field->ball = vertices[0];
                                    str += field->getDistanceChar(t,n);
                                    movesNum++;
                                    moves.push_back(new Move(score,str,terminate, 0, 0, this->player, NULL));
                                    return moves;
                                }
                            }
                        }
                    }
                }
                unsigned long hash = 0L;
                if (this->player == Player::ONE && score > -200 && score < 200) {
                    field->calculateDistances(Player::ONE);
                    int a = field->distances[field->ball];
                    field->calculateDistances(Player::TWO);
                    int b = field->distances[field->ball];
                    hash = (a << 24) + (b << 16) + (player==Player::ONE?0:(1<<15)) + field->ball + ((ruchy/1)<<8);
                }
                field->ball = t;
                field->removeEdge(t,n);
                str += field->getDistanceChar(t,n);
                movesNum++;
                if (score > alpha) {
                    alpha = score;
                    if (alpha >= beta) {
                        for (int i=0;i<konceEdges.size()/2;i++) {
                            field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                        }
                        for (auto &p : paths) field->removeEdge(p.a,p.b);
                        field->ball = vertices[0];
                        moves.push_back(new Move(score,str,terminate, 0, 0, this->player, NULL, hash));
                        return moves;
                    }
                }
                moves.push_back(new Move(score,str,terminate, 0, 0, this->player, NULL, hash));
                str.pop_back();
                if (moves.size() >= limit) break;
            }
        }
        vertices.erase(vertices.begin()+1,vertices.end());
        str.clear();
        for (auto &p : paths) field->removeEdge(p.a,p.b);
        field->ball = vertices[0];
    }

    for (int i=0;i<konceEdges.size()/2;i++) {
        field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
    }

    return moves;
}

int Cpu::getScore(Player player, int level, int alpha, int beta) {
    if (isReleased) return NOTDEFINED;
    if (measureTime) {
        high_resolution_clock::time_point stop = high_resolution_clock::now();
        if (duration_cast<microseconds>( stop - start ).count() >= maxTime) {
            return NOTDEFINED;
        }
    }
    Player opponent = player==Player::ONE?Player::TWO:Player::ONE;
    int output = NOTDEFINED;
    unsigned int size = 0;
    deque<pair<int,vector<Path> > > talia;
    vector<int> vertices; vertices.reserve(25);
    vector<int> pathCycles; pathCycles.reserve(25);
    vector<int> blockedMoves; blockedMoves.reserve(25);
    vertices.push_back(field->ball);
    talia.push_back(make_pair(field->ball,vector<Path>()));
    bool maximizer = this->player == player;
    vector<int> ns(8);
    vector<int> nsBlocked(8);
    vector<int> nsBlocking(8);
    vector<int> konceEdges;
    bool check = true;
    if (!field->onlyOneEmpty()) {
        konceEdges = field->fillBlockedKonce();
        field->calculateDistances(player);
        check = field->distances[field->ball] < 3;
    }
    int loop = 0;
    while (!talia.empty() && size < limit) {
        loop++;
        pair<int,vector<Path> > v_paths;
        if ((loop&15) == 0) {
            v_paths = talia.front();
            talia.pop_front();
        } else {
            v_paths = talia.back();
            talia.pop_back();
        }
        int t = v_paths.first;
        vector<Path> & paths = v_paths.second;
        for (auto &p : paths) {
            field->addEdge(p.a,p.b);
            vertices.push_back(p.b);
        }
        field->ball = t;
        field->fillFreeNeibghours(ns,t);
        FisherYates(ns);
        int blocked = -1;
        int blocking = -1;
        for (auto &n : ns) {
            if (/*goal == Player::NONE &&*/ !field->isAlmostBlocked(n) && field->passNext(n)) {
                vector<Path> newPaths(paths);
                newPaths.push_back(Path(t,n));
                if (find(vertices.begin(), vertices.end(), n) != vertices.end()) {
                    int newPathsHash = hashPaths(newPaths);
                    if (find(pathCycles.begin(), pathCycles.end(), newPathsHash) == pathCycles.end()) {
                        pathCycles.push_back(newPathsHash);
                        talia.push_back(make_pair(n,newPaths));
                    }
                } else talia.push_back(make_pair(n,newPaths));
            } else {
                Player goal = field->goal(n);
                field->addEdge(t,n);
                field->ball = n;
                int p = this->player==Player::ONE?0:1;
                int score = scoresArray[n][p];
                if (goal != Player::NONE) {
                    if (goal == this->player) score = MIN_GOAL-level;
                    else score = MAX_GOAL+level;
                } else {
                    if (field->isBlocked(n)) {
                        vector<Path> newPaths(paths);
                        newPaths.push_back(Path(t,n));
                        int newPathsHash = hashPaths(newPaths);
                        if (find(blockedMoves.begin(), blockedMoves.end(), newPathsHash) != blockedMoves.end()) {
                            field->ball = t;
                            field->removeEdge(t,n);
                            continue;
                        }
                        blockedMoves.push_back(newPathsHash);
                        score = maximizer?MIN_BLOCKED-level:MAX_GOAL+level;
                    } else {
                        if (check && field->isNextMoveGameover(player)) {
                            score = maximizer?MIN_GOAL_NEXT_MOVE-level:MAX_GOAL+level;
                        } else if (field->onlyOneEmpty()) {
                            score = maximizer?MAX_ONE_EMPTY+level:MIN_GOAL_ONE_EMPTY-level;
                        } else if (field->onlyTwoEmpty()) {
                            score = maximizer?MIN_GOAL_ONE_EMPTY-level:MAX_ONE_EMPTY+level;
                        } else {
                            if (blocked == -1) {
                                blocked = (!alreadyBlocked && field->passNextDone2(t) && field->isCutOffFromOpponentGoal(this->player)) ? 1 : 0;
                                field->fillFreeNeibghours(nsBlocked,n);
                                nsBlocked.push_back(n);
                            }
                            bool b = false;
                            if (find(nsBlocked.begin(),nsBlocked.end(),n) != nsBlocked.end()) {
                                b = blocked == 1;
                            } else {
                                b = (!alreadyBlocked && field->passNextDone2(t) && field->isCutOffFromOpponentGoal(this->player));
                            }
                            if (b) {
                                score = MIN_CUTOFF-level;
                            } else {
                                if (blocking == -1) {
                                    blocking = (!alreadyBlocking && field->passNextDone2(t) && field->isCutOffFromOpponentGoal(this->player==Player::ONE?Player::TWO:Player::ONE)) ? 1 : 0;
                                    field->fillFreeNeibghours(nsBlocking,n);
                                    nsBlocking.push_back(n);
                                }
                                bool b2 = false;
                                if (find(nsBlocking.begin(),nsBlocking.end(),n) != nsBlocking.end()) {
                                    b2 = blocking == 1;
                                } else {
                                    b2 = (!alreadyBlocking && field->passNextDone2(t) && field->isCutOffFromOpponentGoal(this->player==Player::ONE?Player::TWO:Player::ONE));
                                }
                                if (b2) {
                                    score = MAX_CUTOFF+level;
                                    alreadyBlocking = true;
                                    int t = limit;
                                    limit = 30;
                                    int s = getScore(opponent,-1,-500,MAX_GOAL+level);
                                    limit = t;
                                    alreadyBlocking = false;
                                    if (s > -100) score = MAX_CUTOFF+level;
                                    else score = s;

                                } else {
                                    if (level > 0) {
                                        score = getScore(opponent,level-1,alpha,beta);
                                        if (score == NOTDEFINED) {
                                            field->removeEdge(t,n);
                                            for (auto &p : paths) field->removeEdge(p.a,p.b);
                                            for (int i=0;i<konceEdges.size()/2;i++) {
                                                field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                                            }
                                            field->ball = vertices[0];
                                            return NOTDEFINED;
                                        }
                                    } else if (level == 0 && field->isNextMoveGameover(opponent)) {
                                        score = getScore(opponent,level-1,alpha,beta);
                                        if (score == NOTDEFINED) {
                                            field->removeEdge(t,n);
                                            for (auto &p : paths) field->removeEdge(p.a,p.b);
                                            for (int i=0;i<konceEdges.size()/2;i++) {
                                                field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                                            }
                                            field->ball = vertices[0];
                                            return NOTDEFINED;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                field->ball = t;
                field->removeEdge(t,n);
                movesNum++;
                size++;
                if (output == NOTDEFINED) output = score;
                if (maximizer) {
                    if (score > output) output = score;
                    if (output > alpha) {
                        alpha = output;
                        if (alpha >= beta) {
                            if (alpha == beta) output++;
                            for (int i=0;i<konceEdges.size()/2;i++) {
                                field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                            }
                            for (auto &p : paths) field->removeEdge(p.a,p.b);
                            field->ball = vertices[0];
                            return output;
                        }
                    }
                } else {
                    if (score < output) output = score;
                    if (output < beta) {
                        beta = output;
                        if (alpha >= beta) {
                            if (alpha == beta) output--;
                            for (int i=0;i<konceEdges.size()/2;i++) {
                                field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                            }
                            for (auto &p : paths) field->removeEdge(p.a,p.b);
                            field->ball = vertices[0];
                            return output;
                        }
                    }
                }
                if (size >= limit) break;
            }
        }
        vertices.erase(vertices.begin()+1,vertices.end());
        for (auto &p : paths) field->removeEdge(p.a,p.b);
        field->ball = vertices[0];
    }
    for (int i=0;i<konceEdges.size()/2;i++) {
        field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
    }

    if (output == NOTDEFINED) output = maximizer?MIN_BLOCKED-level:MAX_GOAL+level;
    return output;
}

vector<Move*> Cpu::getMoves2(Move *parent, Player player, int limit, int level, int poziomy) {
    vector<Move*> moves; moves.reserve(50);
    deque<pair<int,vector<Path> > > talia;
    vector<int> vertices; vertices.reserve(25);
    vector<int> pathCycles; pathCycles.reserve(25);
    vector<int> blockedMoves; blockedMoves.reserve(25);
    string str = "";
    vertices.push_back(field->ball);
    talia.push_back(make_pair(field->ball,vector<Path>()));
    vector<int> ns(8);
    vector<int> konceEdges;
    bool check = true;
    if (!field->onlyOneEmpty()) {
        konceEdges = field->fillBlockedKonce();
        field->calculateDistances2(player);
        check = field->distances[field->ball] < 3;
    }
    int loop = 0;
    bool alreadyBlocking = this->player == player ? this->alreadyBlocking : this->alreadyBlocked;
    bool alreadyBlocked = this->player == player ? this->alreadyBlocked : this->alreadyBlocking;
    while (!talia.empty() && moves.size() < limit) {
        loop++;
        pair<int,vector<Path> > v_paths;
        if ((loop&15) == 0) {
            v_paths = talia.front();
            talia.pop_front();
        } else {
            v_paths = talia.back();
            talia.pop_back();
        }
        int t = v_paths.first;
        vector<Path> & paths = v_paths.second;
        for (auto &p : paths) {
            str += field->getDistanceChar(p.a,p.b);
            field->addEdge(p.a,p.b);
            vertices.push_back(p.b);
        }
        field->ball = t;
        field->fillFreeNeibghours(ns,t);
        FisherYates(ns);
        for (auto &n : ns) {
            if (!field->isAlmostBlocked(n) && field->passNext(n)) {
                vector<Path> newPaths(paths);
                newPaths.push_back(Path(t,n));
                if (find(vertices.begin(), vertices.end(), n) != vertices.end()) {
                    int newPathsHash = hashPaths(newPaths);
                    if (find(pathCycles.begin(), pathCycles.end(), newPathsHash) == pathCycles.end()) {
                        pathCycles.push_back(newPathsHash);
                        talia.push_back(make_pair(n,newPaths));
                    }
                } else talia.push_back(make_pair(n,newPaths));
            } else {
                Player goal = field->goal(n);
                field->addEdge(t,n);
                field->ball = n;
                int score = 0;
                if (goal != Player::NONE) {
                    if (goal == player) score = MIN_GOAL;
                    else score = MAX_GOAL;
                } else {
                    if (field->isBlocked(n)) {
                        vector<Path> newPaths(paths);
                        newPaths.push_back(Path(t,n));
                        int newPathsHash = hashPaths(newPaths);
                        if (find(blockedMoves.begin(), blockedMoves.end(), newPathsHash) != blockedMoves.end()) {
                            field->ball = t;
                            field->removeEdge(t,n);
                            continue;
                        }
                        blockedMoves.push_back(newPathsHash);
                        score = MIN_BLOCKED;
                    } else {
                        if (check && field->isNextMoveGameover(player)) {
                            score = MIN_GOAL_NEXT_MOVE;
                        } else if (field->onlyOneEmpty()) {
                            score = MAX_ONE_EMPTY;
                        } else if (field->onlyTwoEmpty()) {
                            score = MIN_GOAL_ONE_EMPTY;
                        } else if (!alreadyBlocked && field->passNextDone2(t) && field->isCutOffFromOpponentGoal(player)) {
                            score = MIN_CUTOFF;
                        } else if (!alreadyBlocking && field->passNextDone2(t) && field->isCutOffFromOpponentGoal(player==Player::ONE?Player::TWO:Player::ONE)) {
                            score = MAX_CUTOFF;
//                            alreadyBlocking = true;
//                            int t = limit;
//                            limit = 30;
//                            int s = getScore(player==Player::ONE?Player::TWO:Player::ONE,-1,-500,MAX_GOAL+level);
//                            limit = t;
//                            alreadyBlocking = false;
//                            if (s > -100) score = MAX_CUTOFF;
//                            else {
//                                score = s;
//                                //cout << "taka sytuacja 3" << s << endl;
//                            }
                        } else if (level > 0) {
                            int x = getMovesScore2(player==Player::ONE?Player::TWO:Player::ONE,limit,level-1);
                            if (x < -200 || x > 200 || level > 1) score = -x;
                            else {
                                field->calculateDistances(player);
                                score = field->distances[n];
                            }
                        } else {
                            field->calculateDistances(player);
                            score = field->distances[n];
                        }
                    }
                }
                unsigned long hash = 0L;
                if (this->player == Player::ONE && score > -200 && score < 200) {
                    int a,b;
                    if (player == Player::ONE) {
                        a = score;
                        field->calculateDistances(Player::TWO);
                        b = field->distances[field->ball];
                    } else {
                        b = score;
                        field->calculateDistances(Player::ONE);
                        a = field->distances[field->ball];
                    }
                    hash = (a << 24) + (b << 16) + (player==Player::ONE?0:(1<<15)) + field->ball + (((ruchy+poziomy+1)/1) << 8);
                }
//                unsigned long hash = (this->player == Player::TWO || score < -200 || score > 200 /* || poziomy > 2*/) ? 0L : field->getHash();
                field->ball = t;
                field->removeEdge(t,n);
                moves.push_back(new Move(score,str+field->getDistanceChar(t,n),false,0,0,player,parent,hash));
                if (score > 200) {
                    for (auto &p : paths) field->removeEdge(p.a,p.b);
                    field->ball = vertices[0];
                    for (int i=0;i<konceEdges.size()/2;i++) {
                        field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                    }
                    return moves;
                }
            }
        }
        vertices.erase(vertices.begin()+1,vertices.end());
        str.clear();
        for (auto &p : paths) field->removeEdge(p.a,p.b);
        field->ball = vertices[0];
    }

    for (int i=0;i<konceEdges.size()/2;i++) {
        field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
    }

    return moves;
}

vector<ShortMove*> Cpu::getMovePointers2(Player player, int limit, int level) {
    vector<ShortMove*> moves; moves.reserve(40);
    deque<pair<int,vector<Path> > > talia;
    vector<int> vertices; vertices.reserve(16);
    vector<int> pathCycles; pathCycles.reserve(16);
    vector<int> blockedMoves; blockedMoves.reserve(16);
    string str = "";
    vertices.push_back(field->ball);
    talia.push_back(make_pair(field->ball,vector<Path>()));
    vector<int> ns(8);
    vector<int> konceEdges;
    bool check = true;
    if (!field->onlyOneEmpty()) {
        konceEdges = field->fillBlockedKonce();
        field->calculateDistances2(player);
        check = field->distances[field->ball] < 3;
    }
    int loop = 0;
    bool alreadyBlocking = this->player == player ? this->alreadyBlocking : this->alreadyBlocked;
    bool alreadyBlocked = this->player == player ? this->alreadyBlocked : this->alreadyBlocking;
    while (!talia.empty() && moves.size() < limit) {
        loop++;
        pair<int,vector<Path> > v_paths;
        if ((loop&15) == 0) {
            v_paths = talia.front();
            talia.pop_front();
        } else {
            v_paths = talia.back();
            talia.pop_back();
        }
        int t = v_paths.first;
        vector<Path> & paths = v_paths.second;
        for (auto &p : paths) {
            str += field->getDistanceChar(p.a,p.b);
            field->addEdge(p.a,p.b);
            vertices.push_back(p.b);
        }
        field->ball = t;
        field->fillFreeNeibghours(ns,t);
        FisherYates(ns);
        for (auto &n : ns) {
            if (!field->isAlmostBlocked(n) && field->passNext(n)) {
                vector<Path> newPaths(paths);
                newPaths.push_back(Path(t,n));
                if (find(vertices.begin(), vertices.end(), n) != vertices.end()) {
                    int newPathsHash = hashPaths(newPaths);
                    if (find(pathCycles.begin(), pathCycles.end(), newPathsHash) == pathCycles.end()) {
                        pathCycles.push_back(newPathsHash);
                        talia.push_back(make_pair(n,newPaths));
                    }
                } else talia.push_back(make_pair(n,newPaths));
            } else {
                Player goal = field->goal(n);
                field->addEdge(t,n);
                field->ball = n;
                int p = this->player==Player::ONE?0:1;
                int score = scoresArray[n][p];
                if (goal != Player::NONE) {
                    if (goal == player) score = MIN_GOAL;
                    else score = MAX_GOAL;
                } else {
                    if (field->isBlocked(n)) {
                        vector<Path> newPaths(paths);
                        newPaths.push_back(Path(t,n));
                        int newPathsHash = hashPaths(newPaths);
                        if (find(blockedMoves.begin(), blockedMoves.end(), newPathsHash) != blockedMoves.end()) {
                            field->ball = t;
                            field->removeEdge(t,n);
                            continue;
                        }
                        blockedMoves.push_back(newPathsHash);
                        score = MIN_BLOCKED;
                    } else {
                        if (check && field->isNextMoveGameover(player)) {
                            score = MIN_GOAL_NEXT_MOVE;
                        } else if (field->onlyOneEmpty()) {
                            score = MAX_ONE_EMPTY;
                        } else if (field->onlyTwoEmpty()) {
                            score = MIN_GOAL_ONE_EMPTY;
                        } else if (level == 0 && !alreadyBlocked && field->passNextDone2(t) && field->isCutOffFromOpponentGoal(player)) {
                            score = MIN_CUTOFF;
                        } else if (level == 0 && !alreadyBlocking && field->passNextDone2(t) && field->isCutOffFromOpponentGoal(player==Player::ONE?Player::TWO:Player::ONE)) {
                            score = MAX_CUTOFF;
                        } else if (level > 0) {
                            score = -getMovesScore2(player==Player::ONE?Player::TWO:Player::ONE,limit, level-1);
                        } else {
//                            if (this->player == Player::TWO) {
//                                field->calculateDistances(player);
//                                score = field->distances[n];
//                            }
                        }
                    }
                }
                field->ball = t;
                field->removeEdge(t,n);
                moves.push_back(new ShortMove(score,str+field->getDistanceChar(t,n)));
                if (score > 100) {
                    for (auto &p : paths) field->removeEdge(p.a,p.b);
                    field->ball = vertices[0];
                    for (int i=0;i<konceEdges.size()/2;i++) {
                        field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                    }
                    return moves;
                }
            }
        }
        vertices.erase(vertices.begin()+1,vertices.end());
        str.clear();
        for (auto &p : paths) field->removeEdge(p.a,p.b);
        field->ball = vertices[0];
    }

    for (int i=0;i<konceEdges.size()/2;i++) {
        field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
    }

    return moves;
}

int Cpu::getMovesScore2(Player player, int limit, int level) {
    deque<pair<int,vector<Path> > > talia;
    vector<int> vertices; vertices.reserve(25);
    vector<long> pathCycles; pathCycles.reserve(25);
    vector<long> blockedMoves; blockedMoves.reserve(25);
    vertices.push_back(field->ball);
    talia.push_front(make_pair(field->ball,vector<Path>()));
    vector<int> ns(8);
    vector<int> konceEdges = field->fillBlockedKonce();
    int loop = 0;
    int size = 0;
    int output = MIN_BLOCKED;
    bool alreadyBlocking = this->player == player ? this->alreadyBlocking : this->alreadyBlocked;
    bool alreadyBlocked = this->player == player ? this->alreadyBlocked : this->alreadyBlocking;
    while (!talia.empty() && size < limit) {
        loop++;
        pair<int,vector<Path> > v_paths;
        if ((loop&15) == 0) {
            v_paths = talia.back();
            talia.pop_back();
        } else {
            v_paths = talia.front();
            talia.pop_front();
        }
        int t = v_paths.first;
        vector<Path> & paths = v_paths.second;
        for (auto &p : paths) {
            field->addEdge(p.a,p.b);
            vertices.push_back(p.b);
        }
        field->ball = t;
        field->fillFreeNeibghours(ns,t);
        FisherYates(ns);
        for (auto &n : ns) {
            if (!field->isAlmostBlocked(n) && field->passNext(n)) {
                vector<Path> newPaths(paths);
                newPaths.push_back(Path(t,n));
                if (find(vertices.begin(), vertices.end(), n) != vertices.end()) {
                    int newPathsHash = hashPaths(newPaths);
                    if (find(pathCycles.begin(), pathCycles.end(), newPathsHash) == pathCycles.end()) {
                        pathCycles.push_back(newPathsHash);
                        talia.push_front(make_pair(n,newPaths));
                    }
                } else talia.push_front(make_pair(n,newPaths));
            } else {
                Player goal = field->goal(n);
                field->addEdge(t,n);
                field->ball = n;
                int score = 0;
                if (goal != Player::NONE) {
                    if (goal == player) score = MIN_GOAL;
                    else score = MAX_GOAL;
                } else {
                    if (field->isBlocked(n)) {
                        vector<Path> newPaths(paths);
                        newPaths.push_back(Path(t,n));
                        int newPathsHash = hashPaths(newPaths);
                        if (find(blockedMoves.begin(), blockedMoves.end(), newPathsHash) != blockedMoves.end()) {
                            field->ball = t;
                            field->removeEdge(t,n);
                            continue;
                        }
                        blockedMoves.push_back(newPathsHash);
                        score = MIN_BLOCKED;
                    } else {
                        if (field->isNextMoveGameover(player)) {
                            score = MIN_GOAL_NEXT_MOVE;
                        } else if (field->onlyOneEmpty()) {
                            score = MAX_ONE_EMPTY;
                        } else if (field->onlyTwoEmpty()) {
                            score = MIN_GOAL_ONE_EMPTY;
                        } else if (!alreadyBlocked && field->passNextDone2(t) && field->isCutOffFromOpponentGoal(player)) {
                            score = MIN_CUTOFF;
                        } else if (!alreadyBlocking && field->passNextDone2(t) && field->isCutOffFromOpponentGoal(player==Player::ONE?Player::TWO:Player::ONE)) {
                            score = MAX_CUTOFF;
                        } else if (level > 0) {
                            score = getMovesScore2(player==Player::ONE?Player::TWO:Player::ONE,limit,level-1);
                        }
                    }
                }
                field->ball = t;
                field->removeEdge(t,n);
                size++;
                output = max(score,output);
                if (limit > -100) {
                    if (output >= 0) {
                        for (auto &p : paths) field->removeEdge(p.a,p.b);
                        field->ball = vertices[0];
                        for (int i=0;i<konceEdges.size()/2;i++) {
                            field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                        }
                        return output;
                    }
                } else {
                    if (output > 0) {
                        for (auto &p : paths) field->removeEdge(p.a,p.b);
                        field->ball = vertices[0];
                        for (int i=0;i<konceEdges.size()/2;i++) {
                            field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                        }
                        return output;
                    }
                }
            }
        }
        vertices.erase(vertices.begin()+1,vertices.end());
        for (auto &p : paths) field->removeEdge(p.a,p.b);
        field->ball = vertices[0];
    }

    for (int i=0;i<konceEdges.size()/2;i++) {
        field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
    }

    return output;
}

int Cpu::simulateOnePointers2(Player currentPlayer, int limes) {
    vector< vector<Path>> paths;
    while (true) {
        vector<ShortMove*> moves = getMovePointers2(currentPlayer,limes,1);
        sort(moves.begin(),moves.end(), [](ShortMove * a, ShortMove * b) -> bool
        {
            return a->score > b->score;
        });
        int r = 0;
        int t = 0;
        if (moves[0]->score > 200) t = 1;
        else {
            for (auto &move : moves) {
                if (move->score < -200) break;
                r++;
            }
        }

        if (t > 0) {
            while (!paths.empty()) {
                vector<Path> p = paths.back();
                paths.pop_back();
                undoMove(p);
            }
            for (auto m : moves) { delete m; }
            return currentPlayer == this->player ? 1 : 0;
        } else if (r == 0) {
            while (!paths.empty()) {
                vector<Path> p = paths.back();
                paths.pop_back();
                undoMove(p);
            }
            for (auto m : moves) { delete m; }
            return currentPlayer != this->player ? 1 : 0;
        }

        ShortMove* m = moves[randomInt(r)];
        vector<Path> p = makeMove(m->move);
        paths.push_back(p);

        currentPlayer = (currentPlayer == Player::ONE ? Player::TWO : Player::ONE);

        for (auto m : moves) { delete m; }
    }

    return 0;
}

int Cpu::simulateOnePointers3(Player currentPlayer, int limes, map<unsigned long,pair<int,int>> & tt, mutex & ttLock, int poziomy) {
    vector< vector<Path>> paths;
    int ru = ruchy + poziomy + 1;

    while (true) {
        vector<ShortMove*> moves = getMovePointers2(currentPlayer,limes,1);
        sort(moves.begin(),moves.end(), [](ShortMove * a, ShortMove * b) -> bool
        {
            return a->score > b->score;
        });
        int r = 0;
        int t = 0;
        if (moves[0]->score > 200) t = 1;
        else {
            for (auto &move : moves) {
                if (move->score < -200) break;
                r++;
            }
        }

        if (t > 0) {
            bool good = false;
            Player ppp = currentPlayer;
            ppp = (ppp == Player::ONE ? Player::TWO : Player::ONE);

            while (!paths.empty()) {
                field->calculateDistances(Player::ONE);
                int a = field->distances[field->ball];
                field->calculateDistances(Player::TWO);
                int b = field->distances[field->ball];
                unsigned long hash = (a << 24) + (b << 16) + (ppp==Player::ONE?0:(1<<15)) + field->ball + ((ru/1)<<8);
                ttLock.lock();
                tt[hash].first += good ? 1 : 0;
                tt[hash].second++;
                ttLock.unlock();
                vector<Path> p = paths.back();
                paths.pop_back();
                undoMove(p);
                good = !good;
                ppp = (ppp == Player::ONE ? Player::TWO : Player::ONE);
                ru--;
            }
            for (auto m : moves) { delete m; }
            return currentPlayer == this->player ? 1 : 0;
        } else if (r == 0) {
            bool good = true;
            Player ppp = currentPlayer;
            ppp = (ppp == Player::ONE ? Player::TWO : Player::ONE);

            while (!paths.empty()) {
                field->calculateDistances(Player::ONE);
                int a = field->distances[field->ball];
                field->calculateDistances(Player::TWO);
                int b = field->distances[field->ball];
                unsigned long hash = (a << 24) + (b << 16) + (ppp==Player::ONE?0:(1<<15)) + field->ball + ((ru/1)<<8);
                ttLock.lock();
                tt[hash].first += good ? 1 : 0;
                tt[hash].second++;
                ttLock.unlock();
                vector<Path> p = paths.back();
                paths.pop_back();
                undoMove(p);
                good = !good;
                ppp = (ppp == Player::ONE ? Player::TWO : Player::ONE);
                ru--;
            }

            for (auto m : moves) { delete m; }
            return currentPlayer != this->player ? 1 : 0;
        }

        ShortMove* m = moves[randomInt(r)];
        vector<Path> p = makeMove(m->move);
        paths.push_back(p);

        currentPlayer = (currentPlayer == Player::ONE ? Player::TWO : Player::ONE);

        ru++;
        for (auto m : moves) { delete m; }
    }

    return 0;
}

void Cpu::fillRuchy2(vector<Move*> & moves, mutex & kupa) {
    Field *copy = new Field(Size::NORMAL,false);
    copy->ball = field->ball;
    copy->matrix = field->matrix;
    copy->matrixNodes = field->matrixNodes;
    copy->matrixNeibghours = field->matrixNeibghours;

    Cpu cpu(player,difficulty,1, 1);
    cpu.setField(copy);
    cpu.ruchy = ruchy;
    cpu.limit = 100000;
    cpu.start = high_resolution_clock::now();
    cpu.g = 0;
    long duration = duration_cast<microseconds>( high_resolution_clock::now() - cpu.start).count();
    while (duration < maxTime && !cpu.provenEnd) {
        if (this->player == Player::ONE) cpu.wybierz4(moves, g+1, 0, ttGlobal, ttLockGlobal);
        else cpu.wybierz4(moves, g+1, 0);
        kupa.lock();
        g++;
        cpu.g++;
        kupa.unlock();
        duration = duration_cast<microseconds>( high_resolution_clock::now() - cpu.start).count();
    }
}

void Cpu::wybierz4(vector<Move*> & moves, int games, int level) {
    int visits = moves[0]->parent==NULL?games:moves[0]->parent->games;
    double max = -2*INF;
    vector<int> indexes;
    double a = 0.0, b = 0.0, c = 0.0;
    for (int i=0;i<moves.size();i++) {
        Move *move = moves[i];
        a = 0.0; b = 0.0; c = 0.0;
        if (move->score < -200) c = -INF-100;
        else if (move->score > 200) c = INF;
        if (c == 0.0) {
            if (move->games == 0) {
                a = 0.50;
                b = 0.50;
                a += -move->virtualLoss;
                if (level > 0) a += (move->score-1.0) / 25.0;
            } else {
                int g = move->games+move->virtualLoss;
                a = (double)(move->score2) / g;
                b = C * sqrt( log(visits)/g );
                c = c / move->games;

                if (level > 0) {
                    a += 2.0 * move->score / g;
                }
            }
        }

        if (a + b + c > max) {
            max = a + b + c ;
            indexes.clear();
            indexes.push_back(i);
        } else if ((a + b + c) == max) {
            indexes.push_back(i);
        }
    }

    Move *move = moves[indexes[randomInt(indexes.size())]];
    move->lock->lock();
    if (move->score2 < -INF/2 || move->score < -100) {
        bool allChildrenBad = true;
        for (auto & m : moves) {
            if (m->score2 < -INF/2 || m->score < -100) {

            } else {
                allChildrenBad = false;
                break;
            }
        }
        move->score2 = -INF;
        move->games++;
        move->lock->unlock();
        Move *parent = move->parent;
        if (allChildrenBad) {
            if (level == 0) {
                provenEnd = true;
                return;
            }
            if (parent != NULL) {
                parent->lock->lock();
                parent->virtualLoss -= VIRTUAL_LOSS;
                parent->games++;
                parent->score2 = INF;
                parent->lock->unlock();
                parent = parent->parent;
            }
            if (parent != NULL) {
                parent->lock->lock();
                parent->virtualLoss -= VIRTUAL_LOSS;
                parent->games++;
                parent->score2 = -INF;
                parent->lock->unlock();
                parent = parent->parent;
            }
        }
        while (parent != NULL) {
            parent->lock->lock();
            parent->virtualLoss -= VIRTUAL_LOSS;
            parent->score2 += parent->player == move->player ? 0 : 1;
            parent->games++;
            parent->lock->unlock();
            parent = parent->parent;
        }
        return;
    }
    if (move->score2 > INF/2 || move->score > 100) {
        move->games++;
        move->score2 = INF;
        move->lock->unlock();
        if (level == 0) {
            provenEnd = true;
            return;
        }
        Move *parent = move->parent;
        if (parent != NULL) {
            parent->lock->lock();
            parent->virtualLoss -= VIRTUAL_LOSS;
            parent->games++;
            parent->score2 = -INF;
            parent->lock->unlock();
            parent = parent->parent;
        }
        while (parent != NULL) {
            parent->lock->lock();
            parent->virtualLoss -= VIRTUAL_LOSS;
            parent->score2 += parent->player == move->player ? 1 : 0;
            parent->games++;
            parent->lock->unlock();
            parent = parent->parent;
        }
        return;
    }
    vector<Path> paths = makeMove(move->move);
    vector<int> konceEdges = field->fillBlockedKonce();
    alreadyBlocking = field->isCutOffFromOpponentGoal(player==Player::ONE?Player::TWO:Player::ONE);
    alreadyBlocked = field->isCutOffFromOpponentGoal(player);
    move->virtualLoss += VIRTUAL_LOSS;
    if (move->games > 0) {
        if (move->moves.size() > 0) {
            move->lock->unlock();
            wybierz4(move->moves,games,level+1);
        } else if (!(field->isBlocked(field->ball) || field->goal(field->ball)!=Player::NONE)) {
            move->moves = getMoves2(move,(move->player==Player::ONE)?Player::TWO:Player::ONE, limit, 0);

            sort(move->moves.begin(),move->moves.end(), [](const Move *a, const Move *b) -> bool
            {
                return a->score > b->score;
            });

            if (move->moves[0]->score > 100) {
                move->virtualLoss -= VIRTUAL_LOSS;
                move->games++;
                move->score2 = -INF;
                move->lock->unlock();
                Move *parent = move->parent;
                while (parent != NULL) {
                    parent->lock->lock();
                    parent->virtualLoss -= VIRTUAL_LOSS;
                    parent->score2 += parent->player == move->player ? 0 : 1;
                    parent->games++;
                    parent->lock->unlock();
                    parent = parent->parent;
                }
                undoMove(paths);
                for (int i=0;i<konceEdges.size()/2;i++) {
                    field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                }
                return;
            } else if (move->moves[0]->score < -100) {
                move->virtualLoss -= VIRTUAL_LOSS;
                move->games++;
                move->score2 = INF;
                move->lock->unlock();
                Move *parent = move->parent;
                if (parent != NULL) {
                    parent->lock->lock();
                    parent->virtualLoss -= VIRTUAL_LOSS;
                    parent->games++;
                    parent->score2 = -INF;
                    parent->lock->unlock();
                    parent = parent->parent;
                }
                while (parent != NULL) {
                    parent->lock->lock();
                    parent->virtualLoss -= VIRTUAL_LOSS;
                    parent->score2 += parent->player == move->player ? 1 : 0;
                    parent->games++;
                    parent->lock->unlock();
                    parent = parent->parent;
                }
                undoMove(paths);
                for (int i=0;i<konceEdges.size()/2;i++) {
                    field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                }
                return;
            }

            move->lock->unlock();
            wybierz4(move->moves,games,level+1);
        }
    } else {
        if (!(field->isBlocked(field->ball) || field->goal(field->ball)!=Player::NONE)) {
            int score2 = simulateOnePointers2((move->player==Player::ONE)?Player::TWO:Player::ONE,30);
            score2 = move->player == this->player ? score2 : 1 - score2;
            move->virtualLoss -= VIRTUAL_LOSS;
            move->score2 += score2;
            move->games++;
            move->lock->unlock();
            Move *parent = move->parent;
            while (parent != NULL) {
                parent->lock->lock();
                parent->virtualLoss -= VIRTUAL_LOSS;
                parent->score2 += parent->player == move->player ? score2 : 1-score2;
                parent->games++;
                parent->lock->unlock();
                parent = parent->parent;
            }
        }
    }
    undoMove(paths);
    for (int i=0;i<konceEdges.size()/2;i++) {
        field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
    }
}

void Cpu::wybierz4(vector<Move*> & moves, int games, int level, map<unsigned long,pair<int,int>> & tt, mutex & ttLock) {
    int visits = moves[0]->parent==NULL?games:moves[0]->parent->games;
    double max = -2*INF;
    vector<int> indexes;
    double a = 0.0, b = 0.0, c = 0.0;
    for (int i=0;i<moves.size();i++) {
        Move *move = moves[i];
        a = 0.0; b = 0.0; c = 0.0;
        if (move->score < -200) c = -INF-100;
        else if (move->score > 200) c = INF;
        if (c == 0.0) {
            if (move->hash != 0L && tt.find(move->hash) != tt.end()) {
                int wp = tt[move->hash].first;
                int np = tt[move->hash].second;

                int score2 = move->score2;
                int n = move->games;

                double beta = 0.50 * (30.0 - n) / 30.0;
                if (beta < 0.0) beta = 0.0;

                if (n == 0) {
                    beta = 0.25 * np / (100.0 + np);
                    a = beta * wp/np;
                    b = 1 - beta;
                    if (level > 0) {
                        a += (move->score-1.0) / 25.0;
                    }
                    a += -move->virtualLoss;
                } else {
                    int g = n+move->virtualLoss;
//                    a = (double)(score2) / g;
                    a = (1 - beta) * score2 / g + beta * wp/np;
                    b = C * sqrt( log(visits)/g );
                    c = c / move->games;

                    if (level > 0) {
                        a += 2.0 * move->score / g;
                    }
                }
            } else {
                if (move->games == 0) {
                    a = 0.50;
                    b = 0.50;
                    a += -move->virtualLoss;
                    if (level > 0) a += (move->score-1.0) / 25.0;
                } else {
                    int g = move->games+move->virtualLoss;
                    a = (double)(move->score2) / g;
                    b = C * sqrt( log(visits)/g );
                    c = c / move->games;

                    if (level > 0) {
                        a += 2.0 * move->score / g;
                    }
                }
            }
        }

        if (a + b + c > max) {
            max = a + b + c ;
            indexes.clear();
            indexes.push_back(i);
        } else if ((a + b + c) == max) {
            indexes.push_back(i);
        }
    }

    Move *move = moves[indexes[randomInt(indexes.size())]];
    move->lock->lock();
//    if (level > 8 || move->score2 < -INF/2 || move->score < -100) {

//    } else if (move->games > 0 && (move->score2 / (move->games)) < 1/2.) {
//        if (move->hash != 0L && tt.find(move->hash) != tt.end()) {
//            int wp = tt[move->hash].first;
//            int np = tt[move->hash].second;

//            int threshold = 150;
//            if ((np-move->games) > threshold && (1.0*(wp-move->score2)/(np-move->games)) < 0.025) {
//                move->score2 = -INF;
//            }
//        }
//    }
    if (move->score2 < -INF/2 || move->score < -100) {
        bool allChildrenBad = true;
        for (auto & m : moves) {
            if (m->score2 < -INF/2 || m->score < -100) {

            } else {
                allChildrenBad = false;
                break;
            }
        }
        move->score2 = -INF;
        move->games++;
        if (move->hash != 0L) {
            ttLock.lock();
            tt[move->hash].first += 0;
            tt[move->hash].second++;
            ttLock.unlock();
        }
        move->lock->unlock();
        Move *parent = move->parent;
        if (allChildrenBad) {
            if (level == 0) {
                provenEnd = true;
                return;
            }
            if (parent != NULL) {
                parent->lock->lock();
                parent->virtualLoss -= VIRTUAL_LOSS;
                parent->games++;
                parent->score2 = INF;
                if (parent->hash != 0L) {
                    ttLock.lock();
                    tt[parent->hash].first += 1;
                    tt[parent->hash].second++;
                    ttLock.unlock();
                }
                parent->lock->unlock();
                parent = parent->parent;
                if (parent != NULL) {
                    parent->lock->lock();
                    parent->virtualLoss -= VIRTUAL_LOSS;
                    parent->games++;
                    parent->score2 = -INF;
                    if (parent->hash != 0L) {
                        ttLock.lock();
                        tt[parent->hash].first += 0;
                        tt[parent->hash].second++;
                        ttLock.unlock();
                    }
                    parent->lock->unlock();
                    parent = parent->parent;
                }
            }
        }
        while (parent != NULL) {
            parent->lock->lock();
            parent->virtualLoss -= VIRTUAL_LOSS;
            parent->score2 += parent->player == move->player ? 0 : 1;
            parent->games++;
            if (parent->hash != 0L) {
                ttLock.lock();
                tt[parent->hash].first += parent->player == move->player ? 0 : 1;
                tt[parent->hash].second++;
                ttLock.unlock();
            }
            parent->lock->unlock();
            parent = parent->parent;
        }
        return;
    }
//    if (level > 8 || move->score2 > INF/2 || move->score > 100) {

//    } else if (move->games > 0 && (move->score2 / (move->games)) > 1/2. ) {
//        if (move->hash != 0L && tt.find(move->hash) != tt.end()) {
//            int wp = tt[move->hash].first;
//            int np = tt[move->hash].second;

//            int threshold = 150;
//            if ((np-move->games) > threshold && (1.0*(wp-move->score2)/(np-move->games)) > 0.975) {
//                move->score2 = INF;
//            }
//        }
//    }
    if (move->score2 > INF/2 || move->score > 100) {
        move->games++;
        move->score2 = INF;
        if (move->hash != 0L) {
            ttLock.lock();
            tt[move->hash].first += 1;
            tt[move->hash].second++;
            ttLock.unlock();
        }
        move->lock->unlock();
        if (level == 0) {
            provenEnd = true;
            return;
        }
        Move *parent = move->parent;
        if (parent != NULL) {
            parent->lock->lock();
            parent->virtualLoss -= VIRTUAL_LOSS;
            parent->games++;
            parent->score2 = -INF;
            if (parent->hash != 0L) {
                ttLock.lock();
                tt[parent->hash].first += 0;
                tt[parent->hash].second++;
                ttLock.unlock();
            }
            parent->lock->unlock();
            parent = parent->parent;
        }
        while (parent != NULL) {
            parent->lock->lock();
            parent->virtualLoss -= VIRTUAL_LOSS;
            parent->score2 += parent->player == move->player ? 1 : 0;
            parent->games++;
            if (parent->hash != 0L) {
                ttLock.lock();
                tt[parent->hash].first += parent->player == move->player ? 1 : 0;
                tt[parent->hash].second++;
                ttLock.unlock();
            }
            parent->lock->unlock();
            parent = parent->parent;
        }
        return;
    }
    vector<Path> paths = makeMove(move->move);
    vector<int> konceEdges = field->fillBlockedKonce();
    alreadyBlocking = field->isCutOffFromOpponentGoal(player==Player::ONE?Player::TWO:Player::ONE);
    alreadyBlocked = field->isCutOffFromOpponentGoal(player);
    move->virtualLoss += VIRTUAL_LOSS;
    if (move->games > 0) {
        if (move->moves.size() > 0) {
            move->lock->unlock();
            wybierz4(move->moves,games,level+1,tt,ttLock);
        } else if (!(field->isBlocked(field->ball) || field->goal(field->ball)!=Player::NONE)) {
            move->moves = getMoves2(move,(move->player==Player::ONE)?Player::TWO:Player::ONE, limit, 1, level);

            sort(move->moves.begin(),move->moves.end(), [](const Move *a, const Move *b) -> bool
            {
                return a->score > b->score;
            });

            if (move->moves[0]->score > 100) {
                move->virtualLoss -= VIRTUAL_LOSS;
                move->games++;
                move->score2 = -INF;
                if (move->hash != 0L) {
                    ttLock.lock();
                    tt[move->hash].first += 0;
                    tt[move->hash].second++;
                    ttLock.unlock();
                }
                move->lock->unlock();
                Move *parent = move->parent;
                while (parent != NULL) {
                    parent->lock->lock();
                    parent->virtualLoss -= VIRTUAL_LOSS;
                    parent->score2 += parent->player == move->player ? 0 : 1;
                    parent->games++;
                    if (parent->hash != 0L) {
                        ttLock.lock();
                        tt[parent->hash].first += parent->player == move->player ? 0 : 1;
                        tt[parent->hash].second++;
                        ttLock.unlock();
                    }
                    parent->lock->unlock();
                    parent = parent->parent;
                }
                undoMove(paths);
                for (int i=0;i<konceEdges.size()/2;i++) {
                    field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                }
                return;
            } else if (move->moves[0]->score < -100) {
                move->virtualLoss -= VIRTUAL_LOSS;
                move->games++;
                move->score2 = INF;
                if (move->hash != 0L) {
                    ttLock.lock();
                    tt[move->hash].first += 1;
                    tt[move->hash].second++;
                    ttLock.unlock();
                }
                move->lock->unlock();
                Move *parent = move->parent;
                if (parent != NULL) {
                    parent->lock->lock();
                    parent->virtualLoss -= VIRTUAL_LOSS;
                    parent->games++;
                    parent->score2 = -INF;
                    if (parent->hash != 0L) {
                        ttLock.lock();
                        tt[parent->hash].first += 0;
                        tt[parent->hash].second++;
                        ttLock.unlock();
                    }
                    parent->lock->unlock();
                    parent = parent->parent;
                }
                while (parent != NULL) {
                    parent->lock->lock();
                    parent->virtualLoss -= VIRTUAL_LOSS;
                    parent->score2 += parent->player == move->player ? 1 : 0;
                    parent->games++;
                    if (parent->hash != 0L) {
                        ttLock.lock();
                        tt[parent->hash].first += parent->player == move->player ? 1 : 0;
                        tt[parent->hash].second++;
                        ttLock.unlock();
                    }
                    parent->lock->unlock();
                    parent = parent->parent;
                }
                undoMove(paths);
                for (int i=0;i<konceEdges.size()/2;i++) {
                    field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
                }
                return;
            }

            move->lock->unlock();

            wybierz4(move->moves,games,level+1,tt,ttLock);
        }
    } else {
        if (!(field->isBlocked(field->ball) || field->goal(field->ball)!=Player::NONE)) {
            int score2 = simulateOnePointers3((move->player==Player::ONE)?Player::TWO:Player::ONE,30, tt, ttLock, level);
//            int score2 = simulateOnePointers2((move->player==Player::ONE)?Player::TWO:Player::ONE,30);
            score2 = move->player == this->player ? score2 : 1 - score2;
            move->virtualLoss -= VIRTUAL_LOSS;
            move->score2 += score2;
            move->games++;
            if (move->hash != 0L) {
                ttLock.lock();
                tt[move->hash].first += score2;
                tt[move->hash].second++;
                ttLock.unlock();
            }
            move->lock->unlock();
            Move *parent = move->parent;
            while (parent != NULL) {
                parent->lock->lock();
                parent->virtualLoss -= VIRTUAL_LOSS;
                parent->score2 += parent->player == move->player ? score2 : 1-score2;
                parent->games++;
                if (parent->hash != 0L) {
                    ttLock.lock();
                    tt[parent->hash].first += parent->player == move->player ? score2 : 1-score2;
                    tt[parent->hash].second++;
                    ttLock.unlock();
                }
                parent->lock->unlock();
                parent = parent->parent;
            }
        }
    }
    undoMove(paths);
    for (int i=0;i<konceEdges.size()/2;i++) {
        field->removeEdge(konceEdges[2*i],konceEdges[2*i+1]);
    }
}

string Cpu::getBestMoveMCTS() {
    ss.clear();
    if (field->isNextMoveGameover(player==Player::ONE?Player::TWO:Player::ONE)) {
        string output = field->shortWinningMoveForPlayer(this->player);
        ss << "winnig move found: " << output << endl;
        return output;
    }

//    if (ruchy < 400) {
//        measureTime = true;
//        maxTime = 100000 + 30000*ruchy;
//        maxTime = 1;
//        limit = 100;
//        return getBestMove();
//    }

    alreadyBlocking = field->isCutOffFromOpponentGoal(player==Player::ONE?Player::TWO:Player::ONE);
    alreadyBlocked = field->isCutOffFromOpponentGoal(player);
    if (/*alreadyBlocking ||*/ alreadyBlocked) {
        cout << ((this->player == Player::ONE)?"ONE ":"TWO ") << " alreadyBlocked" << endl;
        ss << "alreadyBlocked, using minmax" << endl;
        measureTime = true;
        maxTime = 1000000L;
        limit = 250;
        return getBestMove();
    }

    limit = 100000;
    measureTime = false;
    start = high_resolution_clock::now();
    vector<Move*> moves = getMovesSophisticated(-1);

    sort(moves.begin(),moves.end(), [](const Move *a, const Move *b) -> bool
    {
        return a->score > b->score;
    });

    ttGlobal.clear();
//    int ruch = ruchy - ruchy%2;
//    if (ruch % 6 == 0) ttGlobal.clear();

    if (moves[0]->score >= MAX_CUTOFF-10 || moves[0]->score <= MIN_CUTOFF+10 || moves.size() == 1 || moves[1]->score <= MIN_CUTOFF+10) {
        int max = moves[0]->score;
        cout << ((this->player == Player::ONE)?"ONE ":"TWO ") << "max is " << max << endl;
        int t = 1;
        for (int i=1;i<moves.size();i++) {
            if (max == moves[i]->score) t++;
            else break;
        }
        string output = moves[randomInt(t)]->move;
        ss << "bad, or blocking move, or only one non-losing move found: " << output << endl;
        for (auto & m : moves) { delete m; }
        return output;
    }

    maxTime = time * 1000000L;
    if (alreadyBlocking) {
        cout << "alreadyBlocking" << endl;
        ss << "alreadyBlocking, using less time" << endl;
        maxTime = 1000000L;
    }
//    ttGlobal.clear();

    mutex kupa;
    int n = numThreads;
    g = 0;
    vector<thread> threads; threads.reserve(n);
    for (int i=0;i<n;i++) {
        threads.push_back(thread(&Cpu::fillRuchy2,this,ref(moves),ref(kupa)));
        //threads.push_back(thread(&Cpu::fillRuchy,this,moves,ref(moves),ref(kupa)));
    }

    for (auto &t : threads) t.join();

    sort(moves.begin(),moves.end(), [](const Move *a, const Move *b) -> bool
    {
        int A;
        int B;

        if (a->score < -200) A = -INF-100;
        else {
            A = a->score2;
        }
        if (b->score < -200) B = -INF-100;
        else {
            B = b->score2;
        }
        if (A == B) {
            return a->games > b->games;
        }
        return A > B;
    });

    int max = moves[0]->score2;
    int t = 1;
    for (int i=1;i<moves.size();i++) {
        if (max == moves[i]->score2) t++;
        else break;
    }

    for (auto & m : moves) {
        ss << m->move << ": " << m->score2 << "/" << m->games << endl;
    }
    int sum = 0;
    for (auto & move : moves) {
        sum += move->games;
    }
    cout << "done " << sum << (this->player==Player::ONE?" one ":" two ") << "simulations" << endl;
    ss << moves.size() << " possible moves" << endl;
    ss << "done " << sum << " simulations" << endl;


    Move *move = moves[randomInt(t)];
    if (move->hash == 0L) {
        cout << ((this->player == Player::ONE)?"ONE ":"TWO ") << " srednia " << move->score2 << "/" << move->games << endl;
        ss << "move selected: " + move->move << " : " << move->score2 << "/" << move->games << " " << (1.0*move->score2/move->games) << endl;
    } else {
        cout << ((this->player == Player::ONE)?"ONE ":"TWO ") << " srednia " << move->score2 << "/" << move->games << " vs " << ttGlobal[move->hash].first << "/" << ttGlobal[move->hash].second << endl;
        ss << "move selected: " + move->move << " : " << move->score2 << "/" << move->games << " " << (1.0*move->score2/move->games) << endl;
    }

    ss << "-------------------------------------------------";
    string output = move->move;
    for (auto & m : moves) { delete m; }

    return output;
}

void Cpu::printMoves(vector<Move*> &moves, int level) {
    for (auto & move : moves) {
        for (int i=0;i<level;i++) cout << '*';
        cout << move->move << ": " << move->score2 << "/" << move->games << endl;
        printMoves(move->moves,level+1);
    }
}

vector<Path> Cpu::makeMove(string &move) {
    vector<Path> paths; paths.reserve(move.size());
    for (auto &c : move) {
        int n = nextNode(c);
        paths.push_back(Path(field->ball,n));
        field->addEdge(field->ball,n);
        field->ball = n;
    }
    return paths;
}

void Cpu::undoMove(vector<Path> &paths) {
    field->ball = paths[0].a;
    for (auto &path : paths) {
        field->removeEdge(path.a,path.b);
    }
}

int Cpu::nextNode(char & c) {
    switch(c) {
    case '5': return field->getNeibghour(-1,1);
    case '4': return field->getNeibghour(0,1);
    case '3': return field->getNeibghour(1,1);
    case '6': return field->getNeibghour(-1,0);
    case '2': return field->getNeibghour(1,0);
    case '7': return field->getNeibghour(-1,-1);
    case '0': return field->getNeibghour(0,-1);
    case '1': return field->getNeibghour(1,-1);
    }
    return -1;
}

int Cpu::hashPaths(vector<Path> & paths) {
    int output = 0;
    for (auto &path : paths) { // taken from xorshift32
        int h = 78901*path.hashCode;
        h ^= h << 13;
        h ^= h >> 17;
        //h ^= h << 5;
        output += h;
    }
    return output;
}

void Cpu::release() {
    isReleased = true;
}
