#include "workerthread.h"

void WorkerThread::run() {
    QSettings settings("qtpapersoccer", QSettings::IniFormat);
    int threads = settings.value("threads", QThread::idealThreadCount()).toInt();
    if (threads == 0) threads = 1;
    int time = settings.value("time", 1).toInt();
    if (time == 0) time = 1;
    Cpu cpu(player,Difficulty::NORMAL,threads, time);
    cpu.setField(field);
    cpu.ruchy = ruchy;
    string move = cpu.getBestMoveMCTS();
    emit moveLogs(cpu.ss.str());
    for (auto & c : move) {
        emit moveCalculated(c);
        QThread::msleep(250);
    }
}
