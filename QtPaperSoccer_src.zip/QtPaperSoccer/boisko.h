#ifndef BOISKO_H
#define BOISKO_H

#define LINE_WIDTH 2
#define BOLD_LINE_WIDTH 3
#define BALL_SIZE 6
#define BIG_BALL_SIZE 10

#include <QWidget>
#include <QPaintEvent>
#include <QMouseEvent>
#include <QPainter>
#include <QRect>
#include <QPen>
#include <QBrush>
#include <QFont>
#include <QFontMetrics>
#include <memory>
#include <math.h>

#include "field.h"
#include "game.h"
//#include "cpu.h"

class Boisko : public QWidget
{
    Q_OBJECT
public:
    explicit Boisko(QWidget *parent = 0);
    virtual void paintEvent(QPaintEvent *);
    virtual void mouseReleaseEvent(QMouseEvent *);
    virtual void mouseMoveEvent(QMouseEvent *);

    void setGame(shared_ptr<Game>);

    bool flip = false;

private:
    shared_ptr<Game> game;

    double blocksize;
    double marginWidth;
    double marginHeight;

    int hoverX = -1;
    int hoverY = -1;
};

#endif // BOISKO_H
